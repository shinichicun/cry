# Xenny

* Xenny's tool

## Usage

* Install

    ```bash
    pip3 install xenny
    ```

* and

    ```shell
    Python 3.9.9 (main, Nov 21 2021, 03:22:47) 
    [Clang 12.0.0 (clang-1200.0.32.29)] on darwin
    Type "help", "copyright", "credits" or "license" for more information.
    >>> import xenny.xenny

    Hi I'm Xenny.
    欢迎使用本包。
    也请不要仅依赖本包。
    Do not go gentle into that good night。

    >>> 
    ```