# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :      arnold
   Description :
   Author :         x3nny
   date :           2021/10/8
-------------------------------------------------
   Change Activity:
                    2021/10/8: Init
-------------------------------------------------
"""
__author__ = 'x3nny'

from PIL import  Image

a = Image.new('P',(1,1),1)
a.save('./aaaa.png')