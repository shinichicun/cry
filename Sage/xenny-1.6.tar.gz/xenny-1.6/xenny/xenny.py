print(
'''
Hi I'm Xenny.
欢迎使用本包。
也请不要仅依赖本包。
Do not go gentle into that good night。
''')