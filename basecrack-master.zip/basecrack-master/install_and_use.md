### 安装：

​       直接解压出来，cmd进入解压的文件夹中，使用命令：

`pip3 install -r requirements.txt`安装依赖

### 工具使用：

对来自用户输入的单个Base编码数据进行解码：
`python basecrack.py`
对通过参数（-b/--base）传递的单个Base编码数据进行解码：

`python basecrack.py -b SGVsbG8gV29ybGQh`
对通过文件（-f/--file）传递的多个Base编码数据进行解码：

`python basecrack.py -f file.txt`
对任意模式的多重Base编码数据进行解码（-m/--magic）：

`python basecrack.py --magic`
使用解码的Base数据生成字典文件并输出（-o/--output）：

`python basecrack.py -f file.txt -o output-wordlist.txt`
        